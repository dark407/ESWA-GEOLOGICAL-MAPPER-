ESWA GEOLOGICAL MODELLING ADD-ON PACKAGE

Contents:
- ESWA_Geological_Modelling_Complete_Workflow.txt: full implementation plan and master prompt.
- Reference_Pictures/: the two geological reference pictures supplied by the user.

The pictures are separate image files because a plain .txt file cannot embed binary image data.
Keep this folder beside the text file when sharing the package.
